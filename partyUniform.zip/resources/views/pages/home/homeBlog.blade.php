<div class="colorlib-blog">
    <div class="colorlib-narrow-content">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                <span class="heading-meta">Read</span>
                <h2 class="colorlib-heading">Recent Blog</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 col-sm-6 animate-box" data-animate-effect="fadeInLeft">
                <div class="blog-entry">
                    <a href="#" class="blog-img"><img src="{{ url('pu/team2.jpg') }}" class="img-responsive" alt="HTML5 Bootstrap Template by colorlib.com"></a>
                    <div class="desc">
                        <span><small>April 14, 2018 </small> | <small> bride & maidens </small> | <small> <i class="icon-bubble3"></i> 4</small></span>
                        <h3><a href="#">Packaged all ways</a></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad amet, in ipsa ipsam non quia</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 animate-box" data-animate-effect="fadeInLeft">
                <div class="blog-entry">
                    <a href="#" class="blog-img"><img src="{{ url('pu/celeb.jpg') }}" class="img-responsive" alt="HTML5 Bootstrap Template by colorlib.com"></a>
                    <div class="desc">
                        <span><small>April 14, 2018 </small> | <small>celeb gist </small> | <small> <i class="icon-bubble3"></i> 4</small></span>
                        <h3><a href="#">control your event</a></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad amet, in ipsa ipsam non quia</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 animate-box" data-animate-effect="fadeInLeft">
                <div class="blog-entry">
                    <a href="#" class="blog-img"><img src="{{ url('pu/celeb2.png') }}" class="img-responsive" alt="HTML5 Bootstrap Template by colorlib.com"></a>
                    <div class="desc">
                        <span><small>April 14, 2018 </small> | <small> boss of all bosses </small> | <small> <i class="icon-bubble3"></i> 4</small></span>
                        <h3><a href="#">And the gang is here</a></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad amet, in ipsa ipsam non quia</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>