<!DOCTYPE HTML>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Party Uniform</title>
    <!-- logo for browser tab -->
    <link rel="icon" href="<?php echo e(asset('image/icon.jpg')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="" />

    <!-- Facebook and Twitter integration -->
    <meta property="og:title" content=""/>
    <meta property="og:image" content=""/>
    <meta property="og:url" content=""/>
    <meta property="og:site_name" content=""/>
    <meta property="og:description" content=""/>
    <meta name="twitter:title" content="" />
    <meta name="twitter:image" content="" />
    <meta name="twitter:url" content="" />
    <meta name="twitter:card" content="" />

    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <link rel="shortcut icon" href="favicon.ico">

    <link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,500,700" rel="stylesheet">

    <!-- Animate.css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
    <!-- Icomoon Icon Fonts-->
    <link rel="stylesheet" href="<?php echo e(asset('css/icomoon.css')); ?>">
    <!-- Bootstrap  -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <!-- Flexslider  -->
    <link rel="stylesheet" href="<?php echo e(asset('css/flexslider.css')); ?>">
    <!-- Flaticons  -->
    <link rel="stylesheet" href="<?php echo e(asset('fonts/flaticon/font/flaticon.css')); ?>">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.default.min.css')); ?>">
    <!-- Theme style  -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/puStyle.css')); ?>">

    <!-- Modernizr JS -->
    <script src="<?php echo e(asset('js/modernizr-2.6.2.min.js')); ?>"></script>
    <!-- FOR IE9 below -->
    <!--[if lt IE 9]>
    <script src="<?php echo e(asset('js/respond.min.js')); ?>"></script>
    <![endif]-->

</head>
<body>
<div id="colorlib-page">
    <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="colorlib-main">

        <?php echo $__env->yieldContent('content'); ?>

    </div>
</div>

<!-- jQuery -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<!-- jQuery Easing -->
<script src="<?php echo e(asset('js/jquery.easing.1.3.js')); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<!-- Waypoints -->
<script src="<?php echo e(asset('js/jquery.waypoints.min.js')); ?>"></script>
<!-- Flexslider -->
<script src="<?php echo e(asset('js/jquery.flexslider-min.js')); ?>"></script>
<!-- Sticky Kit -->
<script src="<?php echo e(asset('js/sticky-kit.min.js')); ?>"></script>
<!-- Owl carousel -->
<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
<!-- Counters -->
<script src="<?php echo e(asset('js/jquery.countTo.js')); ?>"></script>


<!-- MAIN JS -->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>

</body>
</html>


