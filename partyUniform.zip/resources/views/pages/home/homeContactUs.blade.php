<div id="get-in-touch" class="colorlib-bg-color">
    <div class="colorlib-narrow-content">
        <div class="row">
            <div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
                <h2>Get in Touch!</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                <p class="colorlib-lead">Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                <p><a href="#" class="btn btn-primary btn-learn">Contact me!</a></p>
            </div>

        </div>
    </div>
</div>