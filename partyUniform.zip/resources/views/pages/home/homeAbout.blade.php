<div class="colorlib-about">
    <div class="colorlib-narrow-content">
        <div class="row">
            <div class="col-md-6">
                <div class="about-img animate-box" data-animate-effect="fadeInLeft" style="background-image: url(pu/wrapa.jpg);">
                </div>
            </div>
            <div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
                <div class="about-desc">
                    <span class="heading-meta">Welcome</span>
                    <h2 class="colorlib-heading">Who we are</h2>
                    <p>We’re Nigeria’s number one event clothiers! It doesn’t matter what your event is: a traditional wedding, white wedding, nikah etc. If you’re going to need your guests to come attired in elegant matching Asoebi, then leave the logistics of all that to us. We want you to focus on the magic of your day. </p>
                    <p>Our highly sought after concierge services take away the stress of kitting up your events so that our clients emerge their finest! We’ll make it your finest hour yet!</p>
                </div>
                <div class="row padding">
                    <div class="col-md-4 no-gutters animate-box" data-animate-effect="fadeInLeft">
                        <a href="#" class="steps active">
                            <p class="icon"><span><i class="icon-check"></i></span></p>
                            <h3>We are <br>pasionate</h3>
                        </a>
                    </div>
                    <div class="col-md-4 no-gutters animate-box" data-animate-effect="fadeInLeft">
                        <a href="#" class="steps">
                            <p class="icon"><span><i class="icon-check"></i></span></p>
                            <h3>Honest <br>Dependable</h3>
                        </a>
                    </div>
                    <div class="col-md-4 no-gutters animate-box" data-animate-effect="fadeInLeft">
                        <a href="#" class="steps">
                            <p class="icon"><span><i class="icon-check"></i></span></p>
                            <h3>Always <br>Improving</h3>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>